#include "arg_utils.hpp"
#include "build_index.hpp"
#include "build_index/centroid_sampling.cuh"
#include "gpu_index_layout.hpp"
#include "io.hpp"

#include <filesystem>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace Chimera;

namespace {

void copy_doclens_into_index_dir(
    const std::string& index_dir,
    const std::string& doclens_filename)
{
    std::filesystem::create_directories(index_dir);
    const auto dest_doclens_path = gpu_index_layout::doclens_path(index_dir);
    const auto source_path = std::filesystem::path(doclens_filename);
    const auto dest_path = std::filesystem::path(dest_doclens_path);
    if (std::filesystem::exists(source_path) &&
        std::filesystem::exists(dest_path) &&
        std::filesystem::equivalent(source_path, dest_path)) {
        return;
    }
    std::filesystem::copy_file(
        source_path,
        dest_path,
        std::filesystem::copy_options::overwrite_existing);
}

void print_input_help(const char* program) {
    std::cout
        << "Usage: " << program
        << " --index_dir <index_dir> --doclens <doclens> --data <data> --n_clusters <n_clusters>\n\n"
        << "Arguments:\n"
        << "  --index_dir   Output index directory.\n"
        << "                The builder writes the split index artifacts into this directory:\n"
        << "                ivf.bin, doc_1bit.bin, doc_4bit.bin,\n"
        << "                cluster_1bit.bin, index_metadata.json, centroids.carga,\n"
        << "                and centroids.hnsw in full mode. *_ex quantization modes\n"
        << "                also write doc_4bit_ex.bin. gpu-search-minimal omits\n"
        << "                index_metadata.json and centroids.hnsw.\n"
        << "  --doclens     Input doclens file.\n"
        << "                Each value is the length of one document, i.e. the number of\n"
        << "                token embeddings belonging to that document.\n"
        << "                This is required to recover document embeddings from token embeddings.\n"
        << "                The file is copied into <index_dir>/doclens.bin.\n"
        << "  --data        Input token embedding file.\n"
        << "                This contains the token embeddings used to build the index.\n"
        << "  --data_loading <mmap|memory|sample-memory>\n"
        << "                mmap reads through a file mapping (default); memory eagerly\n"
        << "                loads every embedding for the whole build; sample-memory\n"
        << "                eagerly loads only for centroid sampling, then releases it\n"
        << "                and uses mmap for the remaining build steps.\n"
        << "  --n_clusters  Number of randomly sampled centroids used to build the CAGRA graph.\n"
        << "  --centroid_sample_bucket_size <count>\n"
        << "                Sample centroids from shuffled contiguous buckets of this many\n"
        << "                token embeddings. Default: 256. Use 1 for fully random sampling.\n"
        << "  --centroid_sample_samples_per_bucket <count>\n"
        << "                When >0, sample up to this many random token embeddings from\n"
        << "                each shuffled contiguous bucket instead of copying whole\n"
        << "                buckets. Default: 0, which preserves whole-bucket sampling.\n"
        << "  --centroid_sample_seed <seed>\n"
        << "                Seed used to shuffle centroid sample buckets. Default: 41.\n"
        << "  --build_mode <full|gpu-search-minimal>\n"
        << "                full writes all artifacts. gpu-search-minimal writes only\n"
        << "                files required by the current GPU search loader. Default: full.\n"
        << "  --quantization <4bit|4bit_ex|8bit|8bit_ex>\n"
        << "                Select the full-code payload bit width and optional residual\n"
        << "                sidecar. Default: 4bit.\n"
        << "  --quantization_backend <cpu|gpu|gpu-merged>\n"
        << "                Select encoder backend. gpu uses CPU rotation followed by\n"
        << "                GPU quantization in Step 5. gpu-merged quantizes assignment\n"
        << "                batches as they leave Step 2. Default: cpu.\n";
}

}  // namespace

int main(int argc, char* argv[]) {
    std::string index_dir;
    std::string data_filename;
    std::string doclens_filename;
    size_t n_clusters = 0;
    std::string data_loading = "mmap";
    BuildIndexOptions build_options;

    if (argc == 1) {
        print_input_help(argv[0]);
        return 1;
    }

    try {
        for (int i = 1; i < argc; ++i) {
            const std::string arg = argv[i];
            if (arg == "--help" || arg == "-h") {
                print_input_help(argv[0]);
                return 0;
            }
            if (arg == "--index_dir") {
                index_dir = require_value(argc, argv, i, arg);
                continue;
            }
            if (arg == "--doclens") {
                doclens_filename = require_value(argc, argv, i, arg);
                continue;
            }
            if (arg == "--data") {
                data_filename = require_value(argc, argv, i, arg);
                continue;
            }
            if (arg == "--n_clusters") {
                n_clusters = std::stoull(require_value(argc, argv, i, arg));
                continue;
            }
            if (arg == "--data_loading" || arg == "--data-loading") {
                data_loading = require_value(argc, argv, i, arg);
                if (data_loading != "mmap" && data_loading != "memory" &&
                    data_loading != "sample-memory") {
                    throw std::runtime_error(
                        "--data_loading must be mmap, memory, or sample-memory, got: " +
                        data_loading);
                }
                continue;
            }
            if (arg == "--centroid_sample_bucket_size" ||
                arg == "--centroid-sample-bucket-size") {
                build_options.centroid_sample.bucket_size =
                    std::stoull(require_value(argc, argv, i, arg));
                continue;
            }
            if (arg == "--centroid_sample_samples_per_bucket" ||
                arg == "--centroid-sample-samples-per-bucket" ||
                arg == "--centroid-samples-per-bucket") {
                build_options.centroid_sample.samples_per_bucket =
                    std::stoull(require_value(argc, argv, i, arg));
                continue;
            }
            if (arg == "--centroid_sample_seed" || arg == "--centroid-sample-seed") {
                build_options.centroid_sample.seed =
                    std::stoull(require_value(argc, argv, i, arg));
                continue;
            }
            if (arg == "--build_mode" || arg == "--build-mode") {
                build_options.output_mode =
                    parse_build_output_mode(require_value(argc, argv, i, arg));
                continue;
            }
            if (arg == "--quantization" || arg == "--quantization-mode") {
                build_options.quantization_mode =
                    parse_quantization_mode(require_value(argc, argv, i, arg));
                continue;
            }
            if (arg == "--quantization_backend" ||
                arg == "--quantization-backend") {
                build_options.quantization_backend =
                    parse_quantization_backend(require_value(argc, argv, i, arg));
                continue;
            }

            throw std::runtime_error("Unknown argument: " + arg);
        }
    } catch (const std::exception& e) {
        std::cerr << "Argument error: " << e.what() << "\n\n";
        print_input_help(argv[0]);
        return 1;
    }

    if (index_dir.empty() || doclens_filename.empty()) {
        std::cerr << "Missing required arguments.\n\n";
        print_input_help(argv[0]);
        return 1;
    }

    auto doc_lens = load_doclens(doclens_filename);
    copy_doclens_into_index_dir(index_dir, doclens_filename);

    if (data_filename.empty() || n_clusters == 0) {
        std::cerr << "Missing required arguments.\n\n";
        print_input_help(argv[0]);
        return 1;
    }

    size_t ex_bits = quantization_full_ex_bits(build_options.quantization_mode);
    MmapedEmbeddings data;
    std::vector<float> precomputed_centroids;
    double data_load_seconds = 0.0;
    double centroid_sample_seconds = 0.0;
    if (data_loading == "sample-memory") {
        {
            const auto data_load_start = std::chrono::steady_clock::now();
            auto sampling_data = load_data_in_memory(data_filename);
            data_load_seconds = std::chrono::duration<double>(
                std::chrono::steady_clock::now() - data_load_start).count();
            const auto centroid_sample_start = std::chrono::steady_clock::now();
            precomputed_centroids = sample_centroids(
                sampling_data, n_clusters, build_options.centroid_sample);
            centroid_sample_seconds = std::chrono::duration<double>(
                std::chrono::steady_clock::now() - centroid_sample_start).count();
        }
        data = load_data_mmap(data_filename);
    } else {
        const auto data_load_start = std::chrono::steady_clock::now();
        data = data_loading == "memory"
            ? load_data_in_memory(data_filename)
            : load_data_mmap(data_filename);
        data_load_seconds = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - data_load_start).count();
    }
    const size_t data_load_bytes = data.num_embeddings * data.d * sizeof(float);
    std::cout << std::fixed << std::setprecision(6)
              << "[data_load] mode=" << data_loading
              << " seconds=" << data_load_seconds
              << " bytes=" << data_load_bytes << "\n";
    if (data_loading == "sample-memory") {
        std::cout << "[centroid_sample] mode=memory seconds="
                  << centroid_sample_seconds << "\n";
        build_options.precomputed_centroids = std::move(precomputed_centroids);
    }
    build_index(data, n_clusters, ex_bits, doc_lens, index_dir, std::move(build_options));
    return 0;
}
