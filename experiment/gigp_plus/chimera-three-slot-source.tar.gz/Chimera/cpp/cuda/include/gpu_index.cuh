#pragma once

#include <memory>

#include "gpu_index_base.cuh"

#include "gpu_kernels.cuh"

namespace Chimera {

struct chimera_index : public chimera_index_base {
    size_t workspace_probe_unique_doc_bound_ = 0;

    doc_bitmap_bucket_t* d_doc_bitmap_ = nullptr;
    doc_bitmap_offset_t* d_doc_bitmap_offsets_ = nullptr;
    size_t doc_bitmap_bucket_count_ = 0;
    size_t doc_bitmap_offset_count_ = 0;
    size_t max_compact_docs_ = 0;
    size_t compact_doc_capacity_ = 0;
    size_t compact_topk_capacity_ = 0;
    char* d_compact_doc_buffer_raw_ = nullptr;
    char* d_compact_doc_buffer_ = nullptr;
    size_t compact_doc_buffer_bytes_ = 0;

    chimera_index(
        const std::string& filename,
        const std::vector<int>& doc_lens,
        const gpu_search_runtime_options& runtime_options);
    chimera_index(
        chimera_index& owner,
        const gpu_search_runtime_options& runtime_options);
    ~chimera_index();

    bool is_query_slot_ = false;
#ifdef CHIMERA_HAVE_CUVS
    raft::resources cagra_res_;
#endif

    void compute_workspace_probe_bounds();
    void allocate_workspace();
    void ensure_compact_doc_capacity(size_t required_rows);

    std::vector<size_t> search(const float* queries, size_t k);
    std::vector<size_t> search_profiled(const float* queries, size_t k);
    template <bool kProfile>
    std::vector<size_t> search_impl(const float* queries, size_t k);

    void rank_cluster_dists_gpu(
        query_object* h_query_objs,
        size_t nprobe,
        size_t k,
        int& actual_k_out,
        cudaStream_t stream = 0);
    template <bool kProfile>
    void rank_cluster_dists_gpu_impl(
        query_object* h_query_objs,
        size_t nprobe,
        size_t k,
        int& actual_k_out,
        cudaStream_t stream = 0);
};


}  // namespace Chimera
