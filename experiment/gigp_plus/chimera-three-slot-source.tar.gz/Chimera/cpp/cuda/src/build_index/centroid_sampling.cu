#include "build_index/centroid_sampling.cuh"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>

namespace Chimera {

std::vector<float> sample_centroids(
    const MmapedEmbeddings& data,
    size_t n_clusters,
    const CentroidSampleOptions& options)
{
    if (n_clusters == 0)
    {
        throw std::runtime_error("n_clusters must be greater than zero");
    }
    if (n_clusters > data.num_embeddings)
    {
        throw std::runtime_error(
            "n_clusters cannot exceed the number of token embeddings");
    }

    const size_t bucket_size = std::max<size_t>(1, options.bucket_size);
    const size_t samples_per_bucket = options.samples_per_bucket;
    std::vector<float> centroids(n_clusters * data.d);

    if (bucket_size == 1 && samples_per_bucket == 0)
    {
        std::vector<size_t> indices(data.num_embeddings);
        std::iota(indices.begin(), indices.end(), 0);
        std::mt19937 rng(static_cast<std::mt19937::result_type>(options.seed));
        std::shuffle(indices.begin(), indices.end(), rng);
        indices.resize(n_clusters);

        for (size_t i = 0; i < n_clusters; ++i)
        {
            std::memcpy(
                &centroids[i * data.d],
                data.embedding_ptr(indices[i]),
                data.d * sizeof(float));
        }
        return centroids;
    }

    const size_t n_buckets = (data.num_embeddings + bucket_size - 1) / bucket_size;
    std::vector<size_t> bucket_ids(n_buckets);
    std::iota(bucket_ids.begin(), bucket_ids.end(), 0);

    std::mt19937 rng(static_cast<std::mt19937::result_type>(options.seed));

    if (samples_per_bucket > 0)
    {
        if (samples_per_bucket * n_buckets < n_clusters)
        {
            throw std::runtime_error(
                "centroid_sample_samples_per_bucket is too small to sample the "
                "requested number of centroids from one pass over the buckets");
        }

        std::vector<size_t> local_offsets(bucket_size);
        std::vector<float> chunk(bucket_size * data.d);
        double data_load_seconds = 0.0;
        double sampling_seconds = 0.0;
        size_t copied = 0;
        for (const size_t bucket_id : bucket_ids)
        {
            if (copied == n_clusters)
            {
                break;
            }

            const size_t start = bucket_id * bucket_size;
            const size_t bucket_count =
                std::min(bucket_size, data.num_embeddings - start);

            const auto data_load_start = std::chrono::steady_clock::now();
            data.copy_embeddings(start, bucket_count, chunk.data());
            data.discard_embeddings(start, bucket_count);
            data_load_seconds += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - data_load_start).count();

            const auto sampling_start = std::chrono::steady_clock::now();
            local_offsets.resize(bucket_count);
            std::iota(local_offsets.begin(), local_offsets.end(), 0);
            std::shuffle(local_offsets.begin(), local_offsets.end(), rng);

            const size_t copy_count =
                std::min({samples_per_bucket, bucket_count, n_clusters - copied});
            for (size_t i = 0; i < copy_count; ++i)
            {
                std::memcpy(
                    &centroids[(copied + i) * data.d],
                    chunk.data() + local_offsets[i] * data.d,
                    data.d * sizeof(float));
            }
            sampling_seconds += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - sampling_start).count();
            copied += copy_count;
        }

        if (copied != n_clusters)
        {
            throw std::runtime_error(
                "Failed to sample the requested number of centroids with "
                "local bucket sampling");
        }

        std::cout << "[centroid_sampling] mode=chunked"
                  << " data_load_seconds=" << data_load_seconds
                  << " sampling_seconds=" << sampling_seconds
                  << " chunk_embeddings=" << bucket_size
                  << " chunks=" << n_buckets << std::endl;

        return centroids;
    }


    std::shuffle(bucket_ids.begin(), bucket_ids.end(), rng);

    size_t copied = 0;
    for (const size_t bucket_id : bucket_ids)
    {
        if (copied == n_clusters)
        {
            break;
        }

        const size_t start = bucket_id * bucket_size;
        const size_t bucket_count =
            std::min(bucket_size, data.num_embeddings - start);
        const size_t copy_count =
            std::min(bucket_count, n_clusters - copied);
        data.copy_embeddings(
            start,
            copy_count,
            centroids.data() + copied * data.d);
        copied += copy_count;
    }

    if (copied != n_clusters)
    {
        throw std::runtime_error("Failed to sample the requested number of centroids");
    }

    return centroids;
}

}  // namespace Chimera
