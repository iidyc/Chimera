#!/usr/bin/env bash
set -euo pipefail

# Creates a fresh binary in node-local storage.  Both CUDA's native GPU target
# and -march=native are therefore resolved on the allocated worker.

repo_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${SLURM_JOB_ID:?SLURM_JOB_ID is required for a per-job build}"
build_target="gpu_search"
if [[ "${1:-}" == "--target" ]]; then
  [[ $# -ge 2 ]] || { echo "error: --target requires a value" >&2; exit 2; }
  build_target="$2"
  shift 2
fi
case "$build_target" in gpu_search|gpu_build) ;; *) echo "error: unsupported target: $build_target" >&2; exit 2 ;; esac
build_dir="${1:-/tmp/chimera_build_${SLURM_JOB_ID}}"
expected_build_dir="/tmp/chimera_build_${SLURM_JOB_ID}${CHIMERA_BUILD_INSTANCE_SUFFIX:-}"
toolchain_root="/home/juelinliu_umass_edu/conda/envs/gpu-mvr"

if [[ "$build_dir" != "$expected_build_dir" ]]; then
  echo "error: per-job build directory must be ${expected_build_dir}" >&2
  exit 2
fi
if [[ -e "$build_dir" ]]; then
  echo "error: refusing to reuse existing per-job build directory ${build_dir}" >&2
  exit 2
fi
if [[ ! -x "${toolchain_root}/bin/cmake" || ! -x "${toolchain_root}/bin/nvcc" ]]; then
  echo "error: expected GPU toolchain under ${toolchain_root}" >&2
  exit 2
fi

cpu_model="$(lscpu | awk -F: '/Model name:/ {sub(/^[[:space:]]+/, "", $2); print $2; exit}')"
gpu_model="$(nvidia-smi --query-gpu=name --format=csv,noheader | head -n1)"
if [[ -z "$gpu_model" ]]; then
  echo "error: no CUDA GPU is visible on this worker" >&2
  exit 7
fi

export PATH="${toolchain_root}/bin:${PATH}"
export CUDAToolkit_ROOT="${toolchain_root}"
export CUDA_HOME="${toolchain_root}"
# CUDA 12.9's front end compiles this project successfully with the system
# GCC 13 toolchain.  The Conda toolchain is GCC 14.3 and fails in CUDA's
# standard-library compatibility layer while compiling centroid_sampling.cu.
# Keep the choice overrideable for clusters where the system compiler lives
# elsewhere, but do not silently fall back to the incompatible Conda compiler.
host_cc="${CHIMERA_HOST_CC:-/usr/bin/gcc-13}"
host_cxx="${CHIMERA_HOST_CXX:-/usr/bin/g++-13}"
if [[ ! -x "$host_cc" || ! -x "$host_cxx" ]]; then
  echo "error: CUDA host compilers not found: CC=${host_cc}, CXX=${host_cxx}" >&2
  exit 2
fi
export CC="$host_cc"
export CXX="$host_cxx"
export CUDAHOSTCXX="$CXX"

echo "[hardware] cpu_model=${cpu_model}"
echo "[hardware] gpu_model=${gpu_model}"
echo "[build] source_commit=$(git -C "$repo_root" rev-parse HEAD)"
echo "[build] source_diff_sha256=$(git -C "$repo_root" diff --binary | sha256sum | awk '{print $1}')"
echo "[build] build_dir=${build_dir}"
echo "[build] target=${build_target}"
echo "[build] host_cc=${CC} ($(${CC} -dumpfullversion -dumpversion))"
echo "[build] host_cxx=${CXX} ($(${CXX} -dumpfullversion -dumpversion))"

cmake -S "${repo_root}/Chimera" -B "$build_dir" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CXX_COMPILER="$CXX" \
  -DCMAKE_CUDA_HOST_COMPILER="$CUDAHOSTCXX" \
  -DCMAKE_CUDA_ARCHITECTURES=native \
  -DCHIMERA_ARCH_FLAGS=-march=native \
  -DCHIMERA_ENABLE_PROFILE=OFF \
  -DCHIMERA_USE_CCACHE=OFF
cmake --build "$build_dir" --target "$build_target" --parallel "${SLURM_CPUS_PER_TASK:-1}"

"$build_dir/$build_target" --help >/dev/null
rg -n 'CMAKE_CUDA_ARCHITECTURES:.*=native|CHIMERA_ARCH_FLAGS:.*-march=native|CHIMERA_ENABLE_PROFILE:BOOL=OFF|CHIMERA_USE_CCACHE:BOOL=OFF' \
  "$build_dir/CMakeCache.txt"
sha256sum "$build_dir/$build_target"
